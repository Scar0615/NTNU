# Configurable Multi-Layer Perceptron (cMLP) Project（All-in-One）
# Testing Phase (All-in-One)

# 讀取訓練資料（testing.xlsx）

import pandas as pd

fd = pd.read_excel('testing.xlsx')

# print(fd.head())
# print(fd.columns)

ilst = [ z for z in fd.columns if 'i' in z ]
olst = [ z for z in fd.columns if 'o' in z ]

# print(ilst)
# print(olst)

m = len(ilst)
n = len(olst)
p = len(fd)

print('dim of ipunt  = ', m)
print('dim of output = ', n)
print('sample number = ', p)

# 讀取 cMLP 組態檔（cmlp.cfg）

with open('cmlp.cfg', 'r') as fp:
    cfg = fp.readlines()
fp.close()

# print(cfg)

cmlp_layer = int(cfg[0].strip())

print('cMLP 層數：', cmlp_layer)

lst = cfg[1].strip().split()
if (cmlp_layer == 3):
    cmlp_layer1 = int(lst[0])
    cmlp_layer2 = int(lst[1])
    cmlp_layer3 = int(lst[2])
    print('cMLP 各層 cell 數：', cmlp_layer1, cmlp_layer2, cmlp_layer3)
    cmlp_in_dim = cmlp_layer1
    cmlp_out_dim = cmlp_layer3
elif (cmlp_layer == 4):
    cmlp_layer1 = int(lst[0])
    cmlp_layer2 = int(lst[1])
    cmlp_layer3 = int(lst[2])
    cmlp_layer4 = int(lst[3])
    print('cMLP 各層 cell 數：', cmlp_layer1, cmlp_layer2, cmlp_layer3, cmlp_layer4)
    cmlp_in_dim = cmlp_layer1
    cmlp_out_dim = cmlp_layer4
elif (cmlp_layer == 5):
    cmlp_layer1 = int(lst[0])
    cmlp_layer2 = int(lst[1])
    cmlp_layer3 = int(lst[2])
    cmlp_layer4 = int(lst[3])
    cmlp_layer5 = int(lst[4])
    print('cMLP 各層 cell 數：', cmlp_layer1, cmlp_layer2, cmlp_layer3, cmlp_layer4, cmlp_layer5)
    cmlp_in_dim = cmlp_layer1
    cmlp_out_dim = cmlp_layer5
elif (cmlp_layer == 6):
    cmlp_layer1 = int(lst[0])
    cmlp_layer2 = int(lst[1])
    cmlp_layer3 = int(lst[2])
    cmlp_layer4 = int(lst[3])
    cmlp_layer5 = int(lst[4])
    cmlp_layer6 = int(lst[5])
    print('cMLP 各層 cell 數：', cmlp_layer1, cmlp_layer2, cmlp_layer3, cmlp_layer4, cmlp_layer5, cmlp_layer6)
    cmlp_in_dim = cmlp_layer1
    cmlp_out_dim = cmlp_layer6
else:
    print('cmlp.cfg 格式錯誤！')

# 維度驗證

if (cmlp_in_dim != m):
    print('樣本輸入維度不一致！')
elif (cmlp_out_dim != n):
    print('樣本輸入維度不一致！')
else:
    print('資料樣本維度一致。')    

# 將資料轉換成 PyTorch Tensor

import torch
import pandas as pd

# 樣本數 p (N)
# 輸入維度 m
# 輸出維度 n
# x: 輸入資料 Tensor
# y: 輸出資料 Tensor

N = p

x = torch.randn(N, m)
y = torch.randn(N, n)

i = 0
for name in ilst:
    for k in range(p):
        x[k,i] = float(fd[name][k])
    i = i + 1

i = 0
for name in olst:
    for k in range(p):
        y[k,i] = float(fd[name][k])
    i = i + 1

# print(x)
# print(y)

# MLP Neuron Definition in PyTorch (Deep Learning)

import torch.nn as nn

if (cmlp_layer == 3):
    class MLPNet(nn.Module):
        def __init__(self):
            super(MLPNet, self).__init__()
            # m inputs (3) -> cmlp_layer2 (128) hiddens --> n outputs (12)
            self.fc1 = nn.Linear(m, cmlp_layer2)
            self.fc2 = nn.Linear(cmlp_layer2, n)
        def forward(self, x):
            x = self.fc1(x).relu()
            x = self.fc2(x)
            return x
elif (cmlp_layer == 4):
    class MLPNet(nn.Module):
        def __init__(self):
            super(MLPNet, self).__init__()
            # m inputs (3) -> cmlp_layer2 (128) hiddens --> cmlp_layer3 (64) hiddens --> n outputs (12)
            self.fc1 = nn.Linear(m, cmlp_layer2)
            self.fc2 = nn.Linear(cmlp_layer2, cmlp_layer3)
            self.fc3 = nn.Linear(cmlp_layer3, n)
        def forward(self, x):
            x = self.fc1(x).relu()
            x = self.fc2(x).relu()
            x = self.fc3(x)
            return x
elif (cmlp_layer == 5):
    class MLPNet(nn.Module):
        def __init__(self):
            super(MLPNet, self).__init__()
            # m inputs (3) -> cmlp_layer2 (128) hiddens --> cmlp_layer3 (64) hiddens -->
            # cmlp_layer4 (32) hiddens --> n outputs (12)
            self.fc1 = nn.Linear(m, cmlp_layer2)
            self.fc2 = nn.Linear(cmlp_layer2, cmlp_layer3)
            self.fc3 = nn.Linear(cmlp_layer3, cmlp_layer4)
            self.fc4 = nn.Linear(cmlp_layer4, n)
        def forward(self, x):
            x = self.fc1(x).relu()
            x = self.fc2(x).relu()
            x = self.fc3(x).relu()
            x = self.fc4(x)
            return x
elif (cmlp_layer == 6):
    class MLPNet(nn.Module):
        def __init__(self):
            super(MLPNet, self).__init__()
            # m inputs (3) -> cmlp_layer2 (128) hiddens --> cmlp_layer3 (64) hiddens -->
            # cmlp_layer4 (32) hiddens --> cmlp_layer5 (16) hiddens --> n outputs (12)
            self.fc1 = nn.Linear(m, cmlp_layer2)
            self.fc2 = nn.Linear(cmlp_layer2, cmlp_layer3)
            self.fc3 = nn.Linear(cmlp_layer3, cmlp_layer4)
            self.fc4 = nn.Linear(cmlp_layer4, cmlp_layer5)
            self.fc5 = nn.Linear(cmlp_layer5, n)
        def forward(self, x):
            x = self.fc1(x).relu()
            x = self.fc2(x).relu()
            x = self.fc3(x).relu()
            x = self.fc4(x).relu()
            x = self.fc5(x)
            return x
else:
    print('cMLP 建構錯誤！')

mlp = MLPNet()

# print(mlp)
print('MLP 建構完成。')

# 載入訓練好的記憶（PyTorch Model）

mlp.load_state_dict(torch.load('cmlp.model', map_location='cpu'))
mlp.eval()
print('Load previous mlp model completely!')

# cMLP Batch Testing

import numpy as np

# 整批測試樣本
# x: inputs
# y: values

# 準備測試樣本，轉變格式成為 Tensor
xt = x

# 測試（feed foreward）
output = mlp(xt)

# 由輸出 Tensor 取出結果
vt = output.tolist()

# MAE, MSE 誤差評估

a, s = 0, 0
for i in range(len(x)):
    a = a + np.abs(y[i]-vt[i][0]).tolist()[0]
    s = s + np.abs(y[i]-vt[i][0]).tolist()[0] * np.abs(y[i]-vt[i][0]).tolist()[0]
mae = a / len(x)
mse = s / len(x)

print('MAE = %10.8f' % (mae))
print('MSE = %10.8f' % (mse))

# 匯出測試記錄（log.csv）

# 開啟測試記錄
fp = open('log.csv', 'w')

# 由輸出 Tensor 取出結果
vt = output.tolist()
tt = y.tolist()

# 欄位名稱
t = ''
for j in range(cmlp_in_dim):
    t = t + 'i,'
for j in range(cmlp_out_dim):
    t = t + 'o,'
t = t + 'Real,Truth\n'
fp.write(t)

# 測試紀錄
for i in range(N):
    t = ''
    lst = x[i].tolist()
    for j in range(cmlp_in_dim):
        t = t + str(lst[j]) + ','
    lst = vt[i]
    for j in range(cmlp_out_dim):
        t = t + str(lst[j]) + ','
    v = vt[i][0]
    u = tt[i][0]
    t = t + str(v) + ',' + str(u) + '\n'
    fp.write(t)

# 關閉測試紀錄
fp.close()

print('測試記錄已匯出（log.csv）')
