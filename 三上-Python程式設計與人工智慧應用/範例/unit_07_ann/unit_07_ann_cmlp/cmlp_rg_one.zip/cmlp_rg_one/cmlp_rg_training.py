# Configurable Multi-Layer Perceptron (cMLP) Project（All-in-One）
# Training Phase (All-in-One)

# 讀取訓練資料（training.xlsx）

import pandas as pd

fd = pd.read_excel('training.xlsx')

# print(fd.head())
# print(fd.columns)

ilst = [ z for z in fd.columns if 'i' in z ]
olst = [ z for z in fd.columns if 'o' in z ]

# print(ilst)
# print(olst)

m = len(ilst)
n = len(olst)
p = len(fd)

print('dim of ipunt  = ', m)
print('dim of output = ', n)
print('sample number = ', p)

# 讀取 cMLP 組態檔（cmlp.cfg）

with open('cmlp.cfg', 'r') as fp:
    cfg = fp.readlines()
fp.close()

# print(cfg)

cmlp_layer = int(cfg[0].strip())

print('cMLP 層數：', cmlp_layer)

lst = cfg[1].strip().split()
if (cmlp_layer == 3):
    cmlp_layer1 = int(lst[0])
    cmlp_layer2 = int(lst[1])
    cmlp_layer3 = int(lst[2])
    print('cMLP 各層 cell 數：', cmlp_layer1, cmlp_layer2, cmlp_layer3)
    cmlp_in_dim = cmlp_layer1
    cmlp_out_dim = cmlp_layer3
elif (cmlp_layer == 4):
    cmlp_layer1 = int(lst[0])
    cmlp_layer2 = int(lst[1])
    cmlp_layer3 = int(lst[2])
    cmlp_layer4 = int(lst[3])
    print('cMLP 各層 cell 數：', cmlp_layer1, cmlp_layer2, cmlp_layer3, cmlp_layer4)
    cmlp_in_dim = cmlp_layer1
    cmlp_out_dim = cmlp_layer4
elif (cmlp_layer == 5):
    cmlp_layer1 = int(lst[0])
    cmlp_layer2 = int(lst[1])
    cmlp_layer3 = int(lst[2])
    cmlp_layer4 = int(lst[3])
    cmlp_layer5 = int(lst[4])
    print('cMLP 各層 cell 數：', cmlp_layer1, cmlp_layer2, cmlp_layer3, cmlp_layer4, cmlp_layer5)
    cmlp_in_dim = cmlp_layer1
    cmlp_out_dim = cmlp_layer5
elif (cmlp_layer == 6):
    cmlp_layer1 = int(lst[0])
    cmlp_layer2 = int(lst[1])
    cmlp_layer3 = int(lst[2])
    cmlp_layer4 = int(lst[3])
    cmlp_layer5 = int(lst[4])
    cmlp_layer6 = int(lst[5])
    print('cMLP 各層 cell 數：', cmlp_layer1, cmlp_layer2, cmlp_layer3, cmlp_layer4, cmlp_layer5, cmlp_layer6)
    cmlp_in_dim = cmlp_layer1
    cmlp_out_dim = cmlp_layer6
else:
    print('cmlp.cfg 格式錯誤！')

# 驗證資料維度的一致性

import pandas as pd

fd = pd.read_excel('training.xlsx')

# print(fd.head())
# print(fd.columns)

ilst = [ z for z in fd.columns if 'i' in z ]
olst = [ z for z in fd.columns if 'o' in z ]

# print(ilst)
# print(olst)

m = len(ilst)
n = len(olst)
p = len(fd)

print('dim of ipunt  = ', m)
print('dim of output = ', n)
print('sample number = ', p)

if (cmlp_in_dim != m):
    print('樣本輸入維度不一致！')
elif (cmlp_out_dim != n):
    print('樣本輸入維度不一致！')
else:
    print('資料樣本維度一致。')

# 將資料轉換成 PyTorch Tensor

import torch
import pandas as pd

# 樣本數 p (N)
# 輸入維度 m
# 輸出維度 n
# x: 輸入資料 Tensor
# y: 輸出資料 Tensor

N = p

x = torch.randn(N, m)
y = torch.randn(N, n)

i = 0
for name in ilst:
    for k in range(p):
        x[k,i] = float(fd[name][k])
    i = i + 1

i = 0
for name in olst:
    for k in range(p):
        y[k,i] = float(fd[name][k])
    i = i + 1

# print(x)
# print(y)

# MLP Neuron Definition in PyTorch (Deep Learning)

import torch.nn as nn

if (cmlp_layer == 3):
    class MLPNet(nn.Module):
        def __init__(self):
            super(MLPNet, self).__init__()
            # m inputs (3) -> cmlp_layer2 (128) hiddens --> n outputs (12)
            self.fc1 = nn.Linear(m, cmlp_layer2)
            self.fc2 = nn.Linear(cmlp_layer2, n)
        def forward(self, x):
            x = self.fc1(x).relu()
            x = self.fc2(x)
            return x
elif (cmlp_layer == 4):
    class MLPNet(nn.Module):
        def __init__(self):
            super(MLPNet, self).__init__()
            # m inputs (3) -> cmlp_layer2 (128) hiddens --> cmlp_layer3 (64) hiddens --> n outputs (12)
            self.fc1 = nn.Linear(m, cmlp_layer2)
            self.fc2 = nn.Linear(cmlp_layer2, cmlp_layer3)
            self.fc3 = nn.Linear(cmlp_layer3, n)
        def forward(self, x):
            x = self.fc1(x).relu()
            x = self.fc2(x).relu()
            x = self.fc3(x)
            return x
elif (cmlp_layer == 5):
    class MLPNet(nn.Module):
        def __init__(self):
            super(MLPNet, self).__init__()
            # m inputs (3) -> cmlp_layer2 (128) hiddens --> cmlp_layer3 (64) hiddens -->
            # cmlp_layer4 (32) hiddens --> n outputs (12)
            self.fc1 = nn.Linear(m, cmlp_layer2)
            self.fc2 = nn.Linear(cmlp_layer2, cmlp_layer3)
            self.fc3 = nn.Linear(cmlp_layer3, cmlp_layer4)
            self.fc4 = nn.Linear(cmlp_layer4, n)
        def forward(self, x):
            x = self.fc1(x).relu()
            x = self.fc2(x).relu()
            x = self.fc3(x).relu()
            x = self.fc4(x)
            return x
elif (cmlp_layer == 6):
    class MLPNet(nn.Module):
        def __init__(self):
            super(MLPNet, self).__init__()
            # m inputs (3) -> cmlp_layer2 (128) hiddens --> cmlp_layer3 (64) hiddens -->
            # cmlp_layer4 (32) hiddens --> cmlp_layer5 (16) hiddens --> n outputs (12)
            self.fc1 = nn.Linear(m, cmlp_layer2)
            self.fc2 = nn.Linear(cmlp_layer2, cmlp_layer3)
            self.fc3 = nn.Linear(cmlp_layer3, cmlp_layer4)
            self.fc4 = nn.Linear(cmlp_layer4, cmlp_layer5)
            self.fc5 = nn.Linear(cmlp_layer5, n)
        def forward(self, x):
            x = self.fc1(x).relu()
            x = self.fc2(x).relu()
            x = self.fc3(x).relu()
            x = self.fc4(x).relu()
            x = self.fc5(x)
            return x
else:
    print('cMLP 建構錯誤！')

mlp = MLPNet()

# print(mlp)
print('MLP 建構完成。')

# Move to GPU

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(device)
mlp = mlp.to(device)

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

EPOCH = 10000

# preparing training samples
# (Ready)

# shuffling definition
def shuffling(x, y):
    x_out = torch.randn(N, cmlp_in_dim)
    y_out = torch.randn(N, cmlp_out_dim)
    idx = [i for i in range(N)]
    idx = np.random.permutation(idx)
    for i in range(N):
        x_out[i] = x[idx[i]]
        y_out[i] = y[idx[i]]
    return x_out, y_out

# Loss function
criterion = nn.MSELoss()
# Optimizer
# optimizer = optim.SGD(mlp.parameters(), lr=0.01)
optimizer = optim.Adam(mlp.parameters(), lr=0.001)

# training
for epoch in range(EPOCH):
    # zero the gradient buffers
    optimizer.zero_grad()
    # shuffling
    x_new, y_new = shuffling(x, y)
    # Move to GPU
    x_new = x_new.to(device)
    y_new = y_new.to(device)
    # feed foreward
    output = mlp(x_new)
    # evaluating loss
    loss = criterion(output, y_new)
    # display loss
    if (epoch % 100 == 0):
        print('epoch = %6d, loss = %12.8f' % (epoch, loss))
    # feed backward
    loss.backward()
    # update parameters
    optimizer.step()

# Save torch model
torch.save(mlp.state_dict(), 'cmlp.model')

print('訓練完畢，cmlp.model 儲存完成。')
